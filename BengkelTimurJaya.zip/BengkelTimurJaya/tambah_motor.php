<!DOCTYPE html>
<?php
    session_start();
    include "action/act_cek.php";
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah Data Motor - Bengkel Timur Jaya Motor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.6.22/css/uikit.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.6.22/js/uikit.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.6.22/js/uikit-icons.min.js"></script>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }
        .navbar {
            background-color: #1e87f0;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            color: #fff;
            font-size: 24px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .nav-link {
            color: #fff;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #ccc;
        }
        .form-box {
            max-width: 600px;
            margin: 0 auto;
            padding: 40px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <nav class="uk-navbar-container navbar" uk-navbar style="background-color:#ffeb3c;">
        <div class="uk-navbar-left">
            <ul class="uk-navbar-nav"><img src="logobengkel.png" width=90px;height=90px;">
                <li class="uk-active"><a href="index.php" class="navbar-brand">Bengkel Timur Jaya Motor</a></li>
                <?php
                if(empty($_SESSION["username"])) {
                    echo "<li><a href='jadwal_service.php' class='nav-link'>Lihat Jadwal Service</a></li>";
                } elseif(isset($_SESSION["username"])) {
                    echo "<li><a href='pesan_jadwal_service.php' class='nav-link'>Reservasi Jadwal Service</a></li>";
                    echo "<li><a href='reservasi_aktif.php' class='nav-link'>Reservasi Service Aktif</a></li>";
                }
                ?>
            </ul>
        </div>
        <div class="uk-navbar-right">
            <ul class="uk-navbar-nav">
                <li>
                    <?php
                    if(empty($_SESSION["username"])) {
                        echo "<a href='#' class='uk-icon-link uk-margin-small-left nav-link' uk-icon='user'>Akun</a>";
                    } elseif(isset($_SESSION["username"])) {
                        $akun = $_SESSION["username"];
                        echo "<a href='#' class='uk-icon-link uk-margin-small-left nav-link' uk-icon='user'>Hai, $akun</a>";
                    }
                    ?>
                    <div class="uk-navbar-dropdown">
                        <ul class="uk-nav uk-navbar-dropdown-nav">
                            <?php
                            if(empty($_SESSION["username"])) {
                                echo "<li class='uk-active'><a href='login.php'>Masuk</a></li>";
                                echo "<li class='uk-active'><a href='daftar.php'>Daftar</a></li>";
                            } elseif(isset($_SESSION["username"])) {
                                echo "<li class='uk-active'><a href='profil.php'>Profil Akun</a></li>";
                                echo "<li class='uk-active'><a href='profil_motor.php'>Data Motor</a></li>";
                                echo "<li class='uk-nav-divider'></li>";
                                echo "<li class='uk-active'><a href='action/act_logout.php'>Keluar</a></li>";
                            }
                            ?>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

    <div class="uk-container" style="padding-top:25px;">
        <?php include "action/act_alert.php"; ?>
        <div class="uk-flex uk-flex-center uk-flex-middle" style="min-height: 70vh;">
            <div class="form-box">
                <h2 class="uk-text-center">Tambah Data Motor</h2>
                <form class="uk-form-stacked" action="action/act_tambah_motor.php" method="post">
                    <div class="uk-margin">
                        <label class="uk-form-label" for="form-stacked-text">Nomor Polisi</label>
                        <div class="uk-form-controls">
                            <input class="uk-input" id="form-stacked-text" type="text" name="no_polisi" placeholder="Masukkan Nomor Polisi" maxlength="10" required>
                        </div>
                    </div>

                    <div class="uk-margin">
                        <label class='uk-form-label' for='form-stacked-select'>Jenis Motor</label>
                        <div class='uk-form-controls'>
                            <select class='uk-select' id='form-stacked-select' name='jenis_motor' required>
                                <option></option>
                                <option>Cub</option>
                                <option>Matic</option>
                                <option>Sport</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="uk-margin">
                        <label class='uk-form-label' for='form-stacked-select'>Merk Motor</label>
                        <div class='uk-form-controls'>
                            <select class='uk-select' id='form-stacked-select' name='merk_motor' required>
                                <option></option>
                                <option>Honda</option>
                                <option>Yamaha</option>
                                <option>Suzuki</option>
                                <option>Kawasaki</option>
                                <option>Lainnya</option>
                            </select>
                        </div>
                    </div>

                    <div class="uk-margin">
                        <label class='uk-form-label' for='form-stacked-text'>Nama Motor</label>
                        <div class='uk-form-controls'>
                            <input class='uk-input' id='form-stacked-text' type='text' name='nama_motor' placeholder='Masukkan Nama Motor' maxlength='20' required>
                        </div>
                    </div>
                    
                    <div class="uk-margin uk-text-center">
                        <button class="uk-button uk-button-primary" type="submit" name="button">TAMBAH MOTOR</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>