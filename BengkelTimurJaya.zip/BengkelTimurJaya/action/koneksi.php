<?php
	$host="localhost";
	$user="root";
	$password="";
	$db="bengkeltimur";
	
	$koneksi=mysqli_connect($host,$user,$password,$db);
?>