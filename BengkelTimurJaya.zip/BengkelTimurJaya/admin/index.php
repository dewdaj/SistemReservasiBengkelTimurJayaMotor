<!DOCTYPE html>
<?php session_start(); ?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.6.22/dist/css/uikit.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
    <style>
        body {
           
    font-family: 'Roboto', sans-serif;
    background: linear-gradient(45deg, #ffcc00, #ff6600); /* Gradien kuning ke oranye */
    min-height: 100vh;
    display: flex;
    flex-direction: column;
  
        }
    </style>
    <title>Bengkel Timur Jaya Motor</title>
</head>
<body>
    <nav class="uk-navbar-container uk-margin-bottom" uk-navbar="mode: click">
        <div class="uk-navbar-left">
        <img src="logo.png" width=90px;height=90px;">
            <a class="uk-navbar-item uk-logo" href="" style="color: #1e87f0; font-size: 2rem; font-weight: bold;">Bengkel Timur Jaya Motor</a>
        </div>
        <div class="uk-navbar-right">
            <ul class="uk-navbar-nav">
                <li>
                    <?php if (empty($_SESSION["username_adm"])) { ?>
                        <a href="#" uk-icon="user" style="color: #1e87f0;">Login</a>
                    <?php } elseif (isset($_SESSION["username_adm"])) {
                        $akun = $_SESSION["username_adm"]; ?>
                        <a href="#" uk-icon="user" style="color: #1e87f0;">Hai, <?= $akun ?></a>
                        <div class="uk-navbar-dropdown">
                            <ul class="uk-nav uk-navbar-dropdown-nav">
                                <li><a href="action/act_logout.php">Keluar</a></li>
                            </ul>
                        </div>
                    <?php } ?>
                </li>
            </ul>
        </div>
    </nav>

    <div class="uk-container uk-flex-1 uk-margin-top uk-margin-bottom">
        <?php include "action/act_alert_admin.php"; ?>
        <div class="uk-card uk-card-default uk-card-body uk-box-shadow-large">
            <h2 class="uk-card-title">Login Admin</h2>
            <form class="uk-form-stacked" action="action/act_masuk_admin.php" method="post" autocomplete="off">
                <div class="uk-margin">
                    <label class="uk-form-label" for="form-stacked-text">Username</label>
                    <div class="uk-inline uk-width-1-1">
                        <span class="uk-form-icon" uk-icon="icon: user"></span>
                        <input class="uk-input" id="form-stacked-text" type="text" name="username_adm" placeholder="Masukkan Username" required>
                    </div>
                </div>
                <div class="uk-margin">
                    <label class="uk -form-label" for="form-stacked-text">Password</label>
                    <div class="uk-inline uk-width-1-1">
                        <span class="uk-form-icon" uk-icon="icon: lock"></span>
                        <input class="uk-input" id="form-stacked-text" type="password" name="password_adm" placeholder="Masukkan Password" required>
                    </div>
                </div>
                <button class="uk-button uk-button-primary uk-width-1-1">Masuk</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/uikit@3.6.22/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.6.22/dist/js/uikit-icons.min.js"></script>
    
</body>
</html>