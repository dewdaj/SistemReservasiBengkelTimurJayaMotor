<!DOCTYPE html>
<?php
session_start();
include "action/act_cek_admin.php";
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }
    </style>
    <title>Bengkel Timur Jaya Motor</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="admin_index.php">
                <img src="logo.png" alt="Bengkel Timur Jaya Motor" width="30" height="30" class="d-inline-block align-top"> Bengkel Timur Jaya Motor</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
    <li class="nav-item dropdown">
        <?php if (empty($_SESSION["username_adm"])) { ?>
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#loginModal">
                <i class="bi bi-person-circle"></i> Login
            </a>
        <?php } elseif (isset($_SESSION["username_adm"])) {
            $akun = $_SESSION["username_adm"]; ?>
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-person-circle"></i> Hai, <?= $akun ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="action/act_logout_admin.php">Keluar</a></li>
            </ul>
        <?php } ?>
    </li>
</ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <?php include "action/act_alert_admin.php"; ?>
        <h2 class="mb-4">Status Reservasi</h2>
        <div class="row">
            <div class="col-md-4 mb-3">
                <form class="d-flex" action="#" method="POST" autocomplete="off">
                    <select class="form-select me-2" id="form-stacked-select" name="status" required>
                        <option value="">Filter Status</option>
                        <option value="Belum">Belum</option>
                        <option value="Proses">Proses</option>
                        <option value="Selesai">Selesai</option>
                        <option value="Batal">Batal</option>
                    </select>
                    <button class="btn btn-primary" type="submit" name="button">Filter</button>
                </form>
            </div>
        </div>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <?php
            include 'action/koneksi.php';
            if (isset($_POST['status'])) {
                $status = $_POST['status'];
                $data = mysqli_query($koneksi, "SELECT * FROM transaksi inner join jadwal on transaksi.kode_jadwal=jadwal.kode_jadwal where status='$status' ORDER BY tanggal,waktu,kode_transaksi asc") or die(mysqli_error($koneksi));
            } elseif (empty($_POST['status'])) {
                $data = mysqli_query($koneksi, "SELECT * FROM transaksi inner join jadwal on transaksi.kode_jadwal=jadwal.kode_jadwal ORDER BY tanggal,waktu,kode_transaksi asc") or die(mysqli_error($koneksi));
            }
            foreach ($data as $baris) { ?>
                <div class="col">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">Kode Transaksi: <a href="admin_transaksi_page.php?kode_transaksi=<?php echo $baris['kode_transaksi'] ?>"><?php echo $baris['kode_transaksi'] ?></a></h5>
                            <p class="card-text">
                                <strong>Tanggal:</strong> <?php echo $baris['tanggal'] ?><br>
                                <strong>Waktu:</strong> <?php echo $baris['waktu'] ?><br>
                                <strong>Username:</strong> <?php echo $baris['username'] ?><br>
                                <strong>Nomor Polisi:</strong> <?php echo $baris['no_polisi'] ?><br>
                                <strong>Status:</strong> <?php echo $baris['status'] ?>
                            </p>
                            <a class="btn btn-danger btn-sm" href="action/act_delete_status_reservasi_admin.php?kode_transaksi=<?php echo $baris['kode_transaksi'] ?>">Hapus</a>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.6.22/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.6.22/dist/js/uikit-icons.min.js"></script>
</body>
</html>