<!DOCTYPE html>
<?php
    session_start();
    include "action/act_cek_admin.php";
?>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/bengkel.css">
	<script src="../js/uikit.min.js"></script>
	<script src="../js/uikit-icons.min.js"></script>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
	<title>Bengkel Timur Jaya Motor</title>
</head>

<body>
    
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="admin_index.php">
            <img src="logo.png" alt="Bengkel Timur Jaya Motor" width="30" height="30" class="d-inline-block align-top"> Bengkel Timur Jaya Motor
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <?php if (empty($_SESSION["username_adm"])) { ?>
                        <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#loginModal"><i class="bi bi-person-circle"></i> Login</a>
                    <?php } elseif (isset($_SESSION["username_adm"])) {
                        $akun = $_SESSION["username_adm"]; ?>
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle"></i> Hai, <?= $akun ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="action/act_logout_admin.php">Keluar</a></li>
                        </ul>
                    <?php } ?>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Tambahkan script Bootstrap di bagian akhir body -->


    <div class="container my-5">
    <?php
        include "action/act_alert_admin.php";
    ?>
    <h2 class="text-center mb-4">Profil Akun</h2>
    <?php
        include 'action/koneksi.php';
        $username=$_GET['username'];
        $data=mysqli_query($koneksi,"SELECT * FROM user WHERE username='$username' ") or die(mysqli_error($koneksi));
        $baris=mysqli_fetch_array($data);
    ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form action="action/act_update_user_admin.php" method="post">
                        <div class="mb-3">
                            <label for="form-stacked-text" class="form-label">Username</label>
                            <input type="text" class="form-control" id="form-stacked-text" name="username" value="<?php echo $baris['username']?>" maxlength="15" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="form-stacked-text" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" id="form-stacked-text" name="nama" value="<?php echo $baris['nama']?>" placeholder="Masukkan Nama Lengkap" maxlength="30" required>
                        </div>
                        <div class="mb-3">
                            <label for="form-stacked-text" class="form-label">Tanggal Lahir</label>
                            <input type="date" class="form-control" id="form-stacked-text" name="tgl_lahir" value="<?php echo $baris['tgl_lahir']?>" min='1910-01-01' max="<?php echo date('Y-m-d');?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="form-stacked-select" class="form-label">Jenis Kelamin</label>
                            <select class="form-select" id="form-stacked-select" name="jk" required>
                                <option value="">Pilih Jenis Kelamin</option>
                                <option value="Pria" <?php if($baris['jk']=='Pria') echo 'selected';?>>Pria</option>
                                <option value="Wanita" <?php if($baris['jk']=='Wanita') echo 'selected';?>>Wanita</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="form-stacked-text" class="form-label">Nomor Telepon</label>
                            <input type="number" class="form-control" id="form-stacked-text" name="no_telp" value="<?php echo $baris['no_telp']?>" maxlength="15" placeholder="Masukkan Nomor Telepon" required>
                        </div>
                        <div class="mb-3">
                            <label for="form-stacked-select" class="form-label">Alamat</label>
                            <textarea class="form-control" rows="3" name="alamat" maxlength="50" placeholder="Masukkan Alamat" required><?php echo $baris['alamat']?></textarea>
                        </div>
                        <button type="submit" name="button" class="btn btn-primary">Ubah</button>
                        <a href="admin_block_user.php" class="btn btn-secondary ms-2">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


</body>
</html>