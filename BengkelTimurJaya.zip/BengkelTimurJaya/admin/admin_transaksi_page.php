<!DOCTYPE html>
<?php
session_start();
include "action/act_cek_admin.php";
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.6.22/dist/css/uikit.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f5f5;
        }
    </style>
    <title>Bengkel Timur Jaya Motor</title>
</head>
<body>
    <nav class="uk-navbar-container uk-margin-bottom" uk-navbar="mode: click">
        <div class="uk-navbar-left">
            <a class="uk-navbar-item uk-logo" href="admin_index.php" style="color: #1e87f0; font-size: 2rem; font-weight: bold;">Bengkel Timur Jaya Motor</a>
        </div>
        <div class="uk-navbar-right">
            <ul class="uk-navbar-nav">
                <li>
                    <?php if (empty($_SESSION["username_adm"])) { ?>
                        <a href="#" uk-icon="user" style="color: #1e87f0;">Login</a>
                    <?php } elseif (isset($_SESSION["username_adm"])) {
                        $akun = $_SESSION["username_adm"]; ?>
                        <a href="#" uk-icon="user" style="color: #1e87f0;">Hai, <?= $akun ?></a>
                        <div class="uk-navbar-dropdown">
                            <ul class="uk-nav uk-navbar-dropdown-nav">
                                <li><a href="action/act_logout_admin.php">Keluar</a></li>
                            </ul>
                        </div>
                    <?php } ?>
                </li>
            </ul>
        </div>
    </nav>

    <div class="uk-container uk-margin-top">
        <?php include "action/act_alert_admin.php"; ?>
        <h2>Profil Akun</h2>
        <?php
        include 'action/koneksi.php';
        $kode_transaksi = $_GET['kode_transaksi'];
        $data = mysqli_query($koneksi, "SELECT * FROM transaksi WHERE kode_transaksi='$kode_transaksi'") or die(mysqli_error($koneksi));
        $baris = mysqli_fetch_array($data);
        ?>
        <div class="uk-card uk-card-default uk-card-body">
            <form class="uk-form-stacked" action="action/act_update_transaksi_user_admin.php" method="post">
                <div class="uk-margin">
                    <label class="uk-form-label" for="form-stacked-text">Kode Transaksi</label>
                    <div class="uk-form-controls">
                        <input class="uk-input" id="form-stacked-text" type="text" name="kode_transaksi" value="<?php echo $baris['kode_transaksi'] ?>" maxlength="15" readonly>
                    </div>
                </div>

                <div class="uk-margin">
                    <label class="uk-form-label" for="form-stacked-select">Status Reservasi</label>
                    <div class="uk-form-controls">
                        <select class="uk-select" id="form-stacked-select" name="status" required>
                            <option value="">Pilih Status</option>
                            <option <?php if ($baris['status'] == 'Belum') echo 'selected="selected"'; ?>>Belum</option>
                            <option <?php if ($baris['status'] == 'Proses') echo 'selected="selected"'; ?>>Proses</option>
                            <option <?php if ($baris['status'] == 'Selesai') echo 'selected="selected"'; ?>>Selesai</option>
                            <option <?php if ($baris['status'] == 'Batal') echo 'selected="selected"'; ?>>Batal</option>
                        </select>
                    </div>
                </div>

                <div class="uk-margin-bottom">
                    <button class="uk-button uk-button-primary" type="submit" name="button">Ubah</button>
                    <a class="uk-button uk-button-default" href="admin_jadwal_reservasi.php">Kembali</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/uikit@3.6.22/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.6.22/dist/js/uikit-icons.min.js"></script>
</body>
</html>