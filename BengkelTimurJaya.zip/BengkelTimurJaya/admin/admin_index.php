<!DOCTYPE html>
<?php session_start(); include "action/act_cek_admin.php"; ?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }
        
        .admin-panel {
            background-color: #212529;
            color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        
        .admin-panel h1 {
            font-weight: 600;
        }
        
        .admin-card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            transition: all 0.3s ease;
            height: 200%;
        }
        
        .admin-card:hover {
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            transform: translateY(-5px);
        }
        
        .admin-card .card-title {
            font-weight: 600;
            color: #212529;
        }
        
        .admin-card .card-text {
            color: #6c757d;
        }
        
        .admin-card .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        
        .admin-card .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }

        .admin-card {
    background-color: #f8f9fa; /* Ubah warna latar belakang kotak */
    border: 1px solid #dee2e6; /* Tambahkan garis tepi pada kotak */
    border-radius: 5px; /* Ubah radius sudut kotak */
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1); /* Ubah bayangan kotak */
    padding: 15px; /* Ubah padding dalam kotak */
    transition: all 0.2s ease; /* Ubah durasi transisi saat kotak dihover */
}

.admin-card:hover {
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); /* Ubah bayangan saat kotak dihover */
    transform: translateY(-3px); /* Ubah transformasi saat kotak dihover */
}

.admin-card .card-title {
    font-weight: 600;
    color: #343a40; /* Ubah warna judul kotak */
}

.admin-card .card-text {
    color: #6c757d; /* Ubah warna teks deskripsi kotak */
}

.admin-card .btn-primary {
    background-color: #007bff; /* Ubah warna latar belakang tombol */
    border-color: #007bff; /* Ubah warna garis tepi tombol */
    color: #fff; /* Ubah warna teks tombol */
}

.admin-card .btn-primary:hover {
    background-color: #0069d9; /* Ubah warna latar belakang tombol saat dihover */
    border-color: #0062cc; /* Ubah warna garis tepi tombol saat dihover */
}
    </style>
    <title>Bengkel Timur Jaya Motor</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="admin_index.php">
                <img src="logo.png" alt="Bengkel Timur Jaya Motor" width="30" height="30" class="d-inline-block align-top"> Bengkel Timur Jaya Motor</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
    <li class="nav-item dropdown">
        <?php if (empty($_SESSION["username_adm"])) { ?>
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#loginModal">
                <i class="bi bi-person-circle"></i> Login
            </a>
        <?php } elseif (isset($_SESSION["username_adm"])) {
            $akun = $_SESSION["username_adm"]; ?>
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-person-circle"></i> Hai, <?= $akun ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="action/act_logout_admin.php">Keluar</a></li>
            </ul>
        <?php } ?>
    </li>
</ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <?php include "action/act_alert_admin.php"; ?>
        <div class="admin-panel rounded-3 mb-4">
            <h1 class="text-center">HALAMAN ADMIN Bengkel Timur Jaya Motor</h1>
        </div>
        <?php if (isset($_SESSION["username_adm"])) { ?>
            <div class="row g-4">
                <div class="col-md-6">
                    <div class="admin-card">
                        <div class="d-flex align-items-center mb-3">
                            <i class="bi bi-calendar-check me-3 fs-1 text-primary"></i>
                            <div>
                                <h5 class="card-title">Jadwal Reservasi</h5>
                                <p class="card-text">Lihat dan kelola jadwal reservasi bengkel.</p>
                            </div>
                        </div>
                        <a href="admin_jadwal_reservasi.php" class="btn btn-primary">Lihat Jadwal</a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="admin-card">
                        <div class="d-flex align-items-center mb-3">
                            <i class="bi bi-person-x me-3 fs-1 text-danger"></i>
                            <div>
                                <h5 class="card-title">Block User</h5>
                                <p class="card-text">Blokir user yang melanggar aturan.</p>
                            </div>
                        </div>
                        <a href="admin_block_user.php" class="btn btn-primary">Kelola User</a>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"></script>
</body>
</html>