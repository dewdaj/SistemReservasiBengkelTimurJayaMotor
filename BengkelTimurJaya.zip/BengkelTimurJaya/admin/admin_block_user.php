<!DOCTYPE html>
<?php
session_start();
include "action/act_cek_admin.php";
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.6.22/dist/css/uikit.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f8f8;
        }
    </style>
    <title>Bengkel Timur Jaya Motor</title>
</head>
<body>
    <nav class="uk-navbar-container uk-margin-bottom" uk-navbar="mode: click">
        <div class="uk-navbar-left">
            <a class="uk-navbar-item uk-logo" href="admin_index.php" style="color: #1e87f0; font-size: 1.8rem; font-weight: 700;">Bengkel Timur Jaya Motor</a>
        </div>
        <div class="uk-navbar-right">
            <ul class="uk-navbar-nav">
                <li>
                    <?php if (empty($_SESSION["username_adm"])) { ?>
                        <a href="#" uk-icon="user" style="color: #1e87f0;">Login</a>
                    <?php } elseif (isset($_SESSION["username_adm"])) {
                        $akun = $_SESSION["username_adm"]; ?>
                        <a href="#" uk-icon="user" style="color: #1e87f0;">Hai, <?= $akun ?></a>
                        <div class="uk-navbar-dropdown">
                            <ul class="uk-nav uk-navbar-dropdown-nav">
                                <li><a href="action/act_logout_admin.php">Keluar</a></li>
                            </ul>
                        </div>
                    <?php } ?>
                </li>
            </ul>
        </div>
    </nav>

    <div class="uk-container uk-margin-top">
        <?php include "action/act_alert_admin.php"; ?>
        <div class="uk-card uk-card-default uk-card-body">
            <h2 class="uk-card-title">Block User</h2>
            <div class="uk-margin-bottom">
                <form class="uk-form-stacked uk-grid-small" uk-grid method="POST" action="#">
                    <div class="uk-width-1-3@s">
                        <div class="uk-inline uk-width-1-1">
                            <span class="uk-form-icon" uk-icon="icon: search"></span>
                            <input class="uk-input" id="form-stacked-text" type="text" name="username" placeholder="Cari User" required>
                        </div>
                    </div>
                    <div class="uk-width-1-3@s">
                        <div class="uk-inline uk-width-1-1">
                            <span class="uk-form-icon" uk-icon="icon: lock"></span>
                            <select class="uk-select" id="form-stacked-select" name="block" required>
                                <option value="">Block User</option>
                                <option value="Tidak">Tidak</option>
                                <option value="Blocked">Blocked</option>
                            </select>
                        </div>
                    </div>
                    <div class="uk-width-1-3@s uk-flex uk-flex-middle">
                        <button class="uk-button uk-button-primary uk-width-1-2" type="submit" name="cari">Cari</button>
                        <button class="uk-button uk-button-primary uk-width-1-2" type="submit" name="set">Set</button>
                    </div>
                </form>
            </div>
            <div class="uk-overflow-auto">
                <table class="uk-table uk-table-striped uk-table-hover uk-table-divider">
                    <thead>
                        <tr>
                            <th><center>Username</center></th>
                            <th><center>Nama</center></th>
                            <th><center>Status</center></th>
                            <th><center>Aksi</center></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'action/koneksi.php';
                        if (isset($_POST['block'])) {
                            $block = $_POST['block'];
                            $data = mysqli_query($koneksi, "SELECT * FROM user where block='$block'") or die(mysqli_error($koneksi));
                        } elseif (isset($_POST['username'])) {
                            $username = $_POST['username'];
                            $data = mysqli_query($koneksi, "SELECT * FROM user where username='$username'") or die(mysqli_error($koneksi));
                        } else {
                            $data = mysqli_query($koneksi, "SELECT * FROM user") or die(mysqli_error($koneksi));
                        }
                        foreach ($data as $baris) { ?>
                            <tr>
                                <td><center><a href='admin_profil_user.php?username=<?php echo $baris['username'] ?>'><?php echo $baris['username'] ?></a></center></td>
                                <td><center><?php echo $baris['nama'] ?></center></td>
                                <td><center><?php echo $baris['block'] ?></center></td>
                                <td><center>
                                    <?php
                                    if ($baris['block'] == "Tidak") { ?>
                                        <a class="uk-button uk-button-danger uk-button-small" href="action/act_block_user_admin.php?username=<?php echo $baris['username'] ?>">Block</a>
                                    <?php } else { ?>
                                        <a class="uk-button uk-button-primary uk-button-small" href="action/act_unblock_user_admin.php?username=<?php echo $baris['username'] ?>">Unblock</a>
                                    <?php }
                                    ?>
                                </center></td>
                            </tr>
                        <?php }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/uikit@3.6.22/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.6.22/dist/js/uikit-icons.min.js"></script>
</body>
</html>