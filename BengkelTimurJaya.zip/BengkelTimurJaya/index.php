<!DOCTYPE html>
<?php session_start(); ?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bengkel Timur Jaya Motor - Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.6.22/css/uikit.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.6.22/js/uikit.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.6.22/js/uikit-icons.min.js"></script>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }
        .navbar {
            background-color: red;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            color: #fff;
            font-size: 24px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .nav-link {
            color: #fff;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #ccc;
        }
        .jumbotron {
            background-color: #f8f9fa;
            padding: 60px 20px;
            text-align: center;
        }
        .jumbotron h1 {
            font-size: 48px;
            font-weight: 700;
            color: #1e87f0;
            margin-bottom: 20px;
        }
        .jumbotron p {
            font-size: 18px;
            color: #555;
            margin-bottom: 30px;
        }
        .list-group-item {
            border: none;
            padding: 10px 20px;
            background-color: #f8f9fa;
            color: #333;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .list-group-item:hover {
            background-color: #e9ecef;
        }
    </style>
</head>
<body>
    <nav class="uk-navbar-container navbar" uk-navbar style="background-color:#ffeb3c;">
        <div class="uk-navbar-left">
            <ul class="uk-navbar-nav"><img src="logobengkel.png" width=90px;height=90px;">
                <li class="uk-active"><a href="index.php" class="navbar-brand">Bengkel Timur Jaya Motor</a></li>
                <?php if(empty($_SESSION["username"])): ?>
                    <li><a href="jadwal_service.php" class="nav-link">Lihat Jadwal Service</a></li>
                <?php else: ?>
                    <li><a href="pesan_jadwal_service.php" class="nav-link">Reservasi Jadwal Service</a></li>
                    <li><a href="reservasi_aktif.php" class="nav-link">Reservasi Service Aktif</a></li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="uk-navbar-right">
            <ul class="uk-navbar-nav">
                <li>
                    <?php if(empty($_SESSION["username"])): ?>
                        <a href="#" class="uk-icon-link uk-margin-small-left nav-link" uk-icon="user">Akun&nbsp;&nbsp;&nbsp;</a>
                    <?php else: ?>
                        <a href="#" class="uk-icon-link uk-margin-small-left nav-link" uk-icon="user">Hai, <?= $_SESSION["username"] ?></a>
                    <?php endif; ?>
                    <div class="uk-navbar-dropdown">
                        <ul class="uk-nav uk-navbar-dropdown-nav">
                            <?php if(empty($_SESSION["username"])): ?>
                                <li><a href="login.php">Masuk</a></li>
                                <li><a href="daftar.php">Daftar</a></li>
                            <?php else: ?>
                                <li><a href="profil.php">Profil Akun</a></li>
                                <li><a href="profil_motor.php">Data Motor</a></li>
                                <li class="uk-nav-divider"></li>
                                <li><a href="action/act_logout.php">Keluar</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

    <div class="jumbotron" style="background-image: url('https://source.unsplash.com/1600x900/?motorcycle,repair'); background-size: cover; background-position: center;">
    <div class="uk-container">
        <h1 style="color: #fff; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">Selamat Datang di BENGKEL TIMUR JAYA MOTOR</h1>
        <p style="color: #fff; text-shadow: 1px 1px 2px rgba(0,0,0,0.5); font-size: 20px;">BENGKEL TIMUR JAYA MOTOR merupakan sistem reservasi jadwal service motor berbasis web.</p>
        <div class="uk-panel uk-panel-box uk-panel-box-primary uk-light" style="background-color: rgba(0,0,0,0.7);">
            <h3 class="uk-panel-title" style="color: #ffeb3c;">Cara Melakukan Reservasi Jadwal Service</h3>
            <ol class="uk-list uk-list-striped list-group">
                <li class="list-group-item" style="background-color: transparent; color: #fff;">1. Daftar dan Login Akun</li>
                <li class="list-group-item" style="background-color: transparent; color: #fff;">2. Isi Data Motor</li>
                <li class="list-group-item" style="background-color: transparent; color: #fff;">3. Pilih Jadwal yang Tersedia</li>
                <li class="list-group-item" style="background-color: transparent; color: #fff;">4. Reservasi Berhasil</li>
                <li class="list-group-item" style="background-color: transparent; color: #fff;">5. Datanglah ke Bengkel dengan Motor yang Direservasikan Sebelumnya</li>
            </ol>
        </div>
    </div>
</div>
</body>
</html>